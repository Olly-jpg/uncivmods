# Resources plus - a unciv mod
Unciv Mod / Resources +

Hello there 
This is my first mod
It contained several sea, bonus,luxury resources with texture. Also buildings unique to resources and land tiles. 

It is capable with 3.10+ and Civ5expansion mod. 

I borrowed some code and image from @Gdansk and @Cavenir. Big thanks to them.

This mod is aimed to enhance affects of resources to individual cities historically so feedback and ideas are welcomed.
